import java.io.*;
import java.security.MessageDigest;
import java.util.*;

public class UserAuth {
    private static final String USER_FILE = "users.txt";

    // Hash passwords for security
    private static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Register new user
    public static boolean register(String username, String password) throws IOException {
        File file = new File(USER_FILE);
        if (!file.exists()) file.createNewFile();

        // Check if username exists
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts[0].equals(username)) {
                    return false; // username taken
                }
            }
        }

        // Save user
        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(username + ":" + hashPassword(password) + "\n");
        }
        return true;
    }

    // Login user
    public static boolean login(String username, String password) throws IOException {
        File file = new File(USER_FILE);
        if (!file.exists()) return false;

        String hashed = hashPassword(password);

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts[0].equals(username) && parts[1].equals(hashed)) {
                    return true;
                }
            }
        }
        return false;
    }
}
